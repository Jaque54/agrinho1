// ===== Menu hambúrguer =====
const hamburguer = document.getElementById('hamburguer');
const navLinks = document.getElementById('nav-links');

hamburguer.addEventListener('click', () => {
  hamburguer.classList.toggle('ativo');
  navLinks.classList.toggle('aberto');
});

// Fecha o menu ao clicar em um link (mobile)
document.querySelectorAll('.nav-links a').forEach((link) => {
  link.addEventListener('click', () => {
    hamburguer.classList.remove('ativo');
    navLinks.classList.remove('aberto');
  });
});

// ===== Cabeçalho muda ao rolar =====
const header = document.getElementById('header');
const voltarTopo = document.getElementById('voltar-topo');

window.addEventListener('scroll', () => {
  if (window.scrollY > 60) {
    header.classList.add('rolado');
  } else {
    header.classList.remove('rolado');
  }

  // Botão voltar ao topo
  if (window.scrollY > 500) {
    voltarTopo.classList.add('visivel');
  } else {
    voltarTopo.classList.remove('visivel');
  }
});

// ===== Botão voltar ao topo =====
voltarTopo.addEventListener('click', () => {
  window.scrollTo({ top: 0, behavior: 'smooth' });
});

// ===== Animação de revelação ao rolar =====
const elementosRevelar = document.querySelectorAll('.revelar');

const observador = new IntersectionObserver(
  (entries) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        entry.target.classList.add('ativo');
        observador.unobserve(entry.target);
      }
    });
  },
  { threshold: 0.15 }
);

elementosRevelar.forEach((el) => observador.observe(el));

// ===== Estatísticas animadas (contador) =====
const numeros = document.querySelectorAll('.numero');
let estatisticasIniciadas = false;

function animarNumero(elemento) {
  const alvo = parseFloat(elemento.getAttribute('data-alvo'));
  const sufixo = elemento.getAttribute('data-sufixo') || '';
  const decimais = elemento.getAttribute('data-decimais') === 'true';
  const duracao = 2000;
  const inicio = performance.now();

  function atualizar(agora) {
    const progresso = Math.min((agora - inicio) / duracao, 1);
    // Suavização (ease-out)
    const eased = 1 - Math.pow(1 - progresso, 3);
    const valor = alvo * eased;
    elemento.textContent = (decimais ? valor.toFixed(1) : Math.floor(valor)) + sufixo;
    if (progresso < 1) {
      requestAnimationFrame(atualizar);
    } else {
      elemento.textContent = (decimais ? alvo.toFixed(1) : alvo) + sufixo;
    }
  }
  requestAnimationFrame(atualizar);
}

const secaoEstatisticas = document.getElementById('estatisticas');

const observadorStats = new IntersectionObserver(
  (entries) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting && !estatisticasIniciadas) {
        estatisticasIniciadas = true;
        numeros.forEach((num) => animarNumero(num));
      }
    });
  },
  { threshold: 0.4 }
);

if (secaoEstatisticas) {
  observadorStats.observe(secaoEstatisticas);
}

// ===== Formulário de contato =====
const formulario = document.getElementById('formulario-contato');
const mensagemSucesso = document.getElementById('mensagem-sucesso');

formulario.addEventListener('submit', (e) => {
  e.preventDefault();

  const nome = document.getElementById('nome').value.trim();
  const email = document.getElementById('email').value.trim();
  const mensagem = document.getElementById('mensagem').value.trim();

  if (!nome || !email || !mensagem) {
    return;
  }

  mensagemSucesso.textContent =
    'Obrigado, ' + nome + '! Sua mensagem foi enviada com sucesso. Em breve entraremos em contato.';
  mensagemSucesso.classList.add('visivel');

  formulario.reset();

  setTimeout(() => {
    mensagemSucesso.classList.remove('visivel');
  }, 6000);
});

// ===== Ano atual no rodapé =====
const anoAtual = document.getElementById('ano');
if (anoAtual) {
  anoAtual.textContent = new Date().getFullYear();
}
